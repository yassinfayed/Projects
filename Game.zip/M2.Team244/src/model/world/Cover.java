package model.world;

import java.awt.*;

public class Cover implements Damageable {
	private int currentHP;
	private Point location;
	private int maxHP;
	
	public Cover(int x, int y) {
		currentHP = (int) (100 + (Math.random() * 900));
		this.maxHP = currentHP;
		location = new Point(x,y);
	}

	public int getCurrentHP() {
		return currentHP;
	}

	public void setCurrentHP(int currentHP) {
		if(currentHP < 0)
			currentHP = 0;
		this.currentHP = currentHP;
	}

	public Point getLocation() {
		return location;
	}
	
	public int getMaxHP() {
		return this.maxHP;
	}
}
