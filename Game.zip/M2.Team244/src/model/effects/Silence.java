package model.effects;

import model.world.Champion;

public class Silence extends Effect {
	public Silence(int duration) {
		super("Silence", duration, EffectType.DEBUFF);
	}

	@Override
	public void apply(Champion C) {
		// TODO Auto-generated method stub
		C.setMaxActionPointsPerTurn(C.getMaxActionPointsPerTurn() + 2);
		C.setCurrentActionPoints(C.getCurrentActionPoints() + 2);
	}

	@Override
	public void remove(Champion C) {
		// TODO Auto-generated method stub
		C.setMaxActionPointsPerTurn(C.getMaxActionPointsPerTurn() - 2);
		C.setCurrentActionPoints(C.getCurrentActionPoints() - 2);
	}
}
