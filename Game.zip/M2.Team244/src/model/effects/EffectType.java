package model.effects;

public enum EffectType {
BUFF,DEBUFF
}
