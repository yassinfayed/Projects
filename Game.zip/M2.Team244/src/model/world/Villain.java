package model.world;

import java.util.ArrayList;

import model.effects.Effect;
import model.effects.EffectType;
import model.effects.Embrace;

public class Villain extends Champion {
	public Villain(String name, int maxHP, int mana, int maxActions, int speed, int attackRange, int attackDamage) {
		super(name, maxHP, mana, maxActions, speed, attackRange, attackDamage);
		super.setCurrentHP(maxHP);
		super.setCurrentActionPoints(maxActions);
	}

	@Override
	public void useLeaderAbility(ArrayList<Champion> targets) {
		for(int i=0; i < targets.size(); i++) {
			Champion target = targets.get(i);
			if(target.getCurrentHP() / target.getMaxHP() < 0.3) {
				target.setCondition(Condition.KNOCKEDOUT);
				target.setCurrentHP(0);
			}
		}
	}
}
