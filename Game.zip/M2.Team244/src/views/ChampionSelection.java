package views;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

//import javafx.scene.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.ToolTipManager;

import model.abilities.Ability;
import model.world.Champion;
import engine.*;

public class ChampionSelection {
	JFrame frame;
	Player player1;
	Player player2;
	Game g;
	Map<String, Boolean> champsSelected;
	//Map<String, Boolean> champsSelected = new HashMap<String, Boolean>();
	
	public ChampionSelection(String player1Name, String player2Name) throws IOException {
		ToolTipManager.sharedInstance().setDismissDelay(9999);
		
        frame = new JFrame("Marvel Heroes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1800,900);
        frame.setLocationRelativeTo(null);

        
        frame.setVisible(true);
        
        player1 = new Player(player1Name);
        player2 = new Player(player2Name);
        g = new Game(player1, player2);
        Game.loadAbilities("./src/Abilities.csv");
        Game.loadChampions("./src/Champions.csv");
        
                
        this.chooseChamps();
	}
	
	private void chooseChamps() {
		champsSelected = new HashMap<String, Boolean>();
		System.out.println(champsSelected.size());
		Player currPlayer;
		if(player1.getLeader() == null) {
			currPlayer = player1;
		} else {
			currPlayer = player2;
		}
		
		JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4,5));
        JLabel headline = new JLabel("<html><center><div style=\"max-width:300px;margin:auto;\">Choose your leader, " + currPlayer.getName() + "</div></center></html>");
        Font f = new Font("SansSerif", Font.PLAIN, 30);        
        headline.setFont(f);
        
        
        panel.add(new JLabel());
        panel.add(new JLabel());
        panel.add(headline);
        panel.add(new JLabel());
        panel.add(new JLabel());
        
        ArrayList<Champion> champions = g.getAvailableChampions();
        
        for(int i=0; i < champions.size(); i++) {
        	Champion c = champions.get(i);
        	champsSelected.put(c.getName(), false);
        	
        	enableChampion(c);
        	
        	JButton btn1 = new JButton(c.getName());
        	
            btn1.setFocusPainted(false);
            btn1.setContentAreaFilled(false);
            
            String abilityStringBuilder = "";
            ArrayList<Ability> championAbilities  = c.getAbilities();
            for(int j=0;j<championAbilities.size();j++) {
            	Ability ability = championAbilities.get(j);
            	
            	String abilityName = ability.getName();
            	abilityStringBuilder += "Ability #" + (j+1) + ": " + abilityName + "<br/>";
            }
            
            btn1.setToolTipText("<html>" + c.getName() + "<br/>Attack Damage: " + c.getAttackDamage() + " health points<br/>Attack Range: " + c.getAttackRange() + " blocks<br/>" + abilityStringBuilder + "</html>");
            btn1.setName(c.getName());
            
            //java.awt.Cursor cursor = new java.awt.Cursor(java.awt.Cursor.CROSSHAIR_CURSOR);
            // btn1.setCursor(cursor);
            
        	if(player1.getTeam().contains(c) && player2.getLeader() == null) {
        		btn1.setEnabled(false);
        	}
            
            btn1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if(champsSelected.get(c.getName()) == false) { // Choose a champion
						if(currPlayer.getLeader() == null) { // Leader
							currPlayer.setLeader(c);
							headline.setText("<html><center><div style=\"max-width:300px;margin:auto;\">Choose your champions, " + currPlayer.getName() + "</div></center></html>");
						}
						
						btn1.setEnabled(false);
						currPlayer.getTeam().add(c);
						if(currPlayer.getTeam().size() == 3) {
							if(player2.getLeader()== null) {
								panel.setVisible(false);
								chooseChamps();
							} else {
								frame.dispose();
								PlayPhase p = new PlayPhase(g);
							}
						}
					}
				}
            });
            panel.add(btn1);
        }
        
        frame.add(panel);
	}
	
	private ImageIcon enableChampion(Champion c) {
    	//String imagePath = ".\\src\\Images\\" + c.getName() + ".png";
        //ImageIcon imageForOne = new ImageIcon(imagePath);
        //imageForOne = new ImageIcon(imageForOne.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH));
        champsSelected.replace(c.getName(), false);
        
        return null;
	}
	
	public int[] getNewDimension() {
		return null;
	}
}
