package model.effects;

import model.world.Champion;

public class Shock extends Effect {
	public Shock(int duration) {
		super("Shock", duration, EffectType.DEBUFF);
	}

	@Override
	public void apply(Champion C) {
		// TODO Auto-generated method stub
		C.setSpeed((int) (C.getSpeed() * 0.9));
		C.setAttackDamage((int) (C.getAttackDamage() * 0.9));
		C.setMaxActionPointsPerTurn(C.getMaxActionPointsPerTurn() - 1);
		C.setCurrentActionPoints(C.getCurrentActionPoints() - 1);
	}

	@Override
	public void remove(Champion C) {
		C.setSpeed((int) (C.getSpeed() / 0.9));
		C.setAttackDamage((int) (C.getAttackDamage() / 0.9));
		C.setMaxActionPointsPerTurn(C.getMaxActionPointsPerTurn() + 1);
		C.setCurrentActionPoints(C.getCurrentActionPoints() + 1);
	}
}
