package model.effects;

import java.util.ArrayList;

import model.world.Champion;
import model.world.Condition;

public class Stun extends Effect {
	public Stun(int duration) {
		super("Stun", duration,EffectType.DEBUFF);
	}

	@Override
	public void apply(Champion C) {
		// TODO Auto-generated method stub\
		C.setCondition(Condition.INACTIVE);
	}

	@Override
	public void remove(Champion C) {
		// TODO Auto-generated method stub
		if(C.getCondition() == Condition.INACTIVE) {
			C.setCondition(Condition.ACTIVE);
		}
	}
}
