package model.effects;

import model.world.Champion;

public class Embrace extends Effect {
	public Embrace(int duration) {
		super("Embrace",duration,EffectType.BUFF);
	}

@Override
	public void apply(Champion C) {
		C.setCurrentHP((int) (C.getMaxHP() * 0.2) + C.getCurrentHP());
		C.setMana((int) (C.getMana() * 1.2));
		
		int newSpeed = (int) (C.getSpeed() * 1.2);
		C.setSpeed(newSpeed);
		
		int newAtk = (int) (C.getAttackDamage() * 1.2);
		C.setAttackDamage(newAtk);
	}

@Override
	public void remove(Champion C) {
		C.setSpeed((int) (C.getSpeed() / 1.2));
		C.setAttackDamage((int)(C.getAttackDamage() / 1.2));
	}
}
