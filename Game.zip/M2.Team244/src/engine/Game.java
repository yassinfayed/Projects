package engine;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.Collections;
//import java.util.List;
import java.util.Random;

import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.*;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Condition;
import model.world.Cover;
import model.world.Damageable;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;


public class Game {
	private Player firstPlayer;
	private Player secondPlayer;
	private boolean firstLeaderAbilityUsed;
	private boolean secondLeaderAbilityUsed;

	private static ArrayList<Champion> availableChampions;
	private static ArrayList<Ability> availableAbilities;
	private PriorityQueue turnOrder;

	private static final int BOARDHEIGHT = 5;
	private static final int BOARDWIDTH = 5;
	Object[][] board = new Object[BOARDHEIGHT][BOARDWIDTH];
	
	private ArrayList<Cover> coversOnBoard = new ArrayList<Cover>();
	
	public Game(Player first, Player second) {
		this.firstPlayer = first;
		this.secondPlayer = second;
		
		this.turnOrder = new PriorityQueue(6);

		availableAbilities = new ArrayList<Ability>();
		availableChampions = new ArrayList<Champion>();

		if (first.getTeam().size() != 0) { // Check if team is empty before attempting to place champions
			this.placeChampions();
		}
		this.placeCovers();
		
		this.prepareChampionTurns();
	}

	public void placeChampions() {
		for (int i = 1; i <= firstPlayer.getTeam().size(); i++) {
			board[0][i] = firstPlayer.getTeam().get(i - 1);
			firstPlayer.getTeam().get(i - 1).setLocation(new Point(0, i));


		}
		for (int i = 1; i <= secondPlayer.getTeam().size(); i++) {
			board[BOARDHEIGHT - 1][i] = secondPlayer.getTeam().get(i - 1);
			secondPlayer.getTeam().get(i - 1).setLocation(new Point(BOARDHEIGHT - 1, i));
		}
	}

	private void placeCovers() {
		for (int i = 0; i < 5; i++) {
			Random random = new Random();
			int y = random.nextInt(4);
			int x = random.nextInt(3) + 1;

			if (board[x][y] == null) {
				 Cover newCover = new Cover(x, y);
				 board[x][y] = newCover;
				 this.coversOnBoard.add(newCover);

			} else
				i--;
		}

	}

	public static void loadAbilities(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String s = br.readLine();
		while (s != null) {
			Ability ab = null;
			String[] abilityDetails = s.split(",");
			String name = abilityDetails[1];
			int manaCost = Integer.parseInt(abilityDetails[2]);
			int castRange = Integer.parseInt(abilityDetails[3]);
			int baseCooldown = Integer.parseInt(abilityDetails[4]);
			String effectStr = abilityDetails[5];
			int required = Integer.parseInt(abilityDetails[6]);

			AreaOfEffect area;

			switch (effectStr) {
			case "SELFTARGET":
				area = AreaOfEffect.SELFTARGET;
				break;
			case "SINGLETARGET":
				area = AreaOfEffect.SINGLETARGET;
				break;
			case "TEAMTARGET":
				area = AreaOfEffect.TEAMTARGET;
				break;
			case "DIRECTIONAL":
				area = AreaOfEffect.DIRECTIONAL;
				break;
			default: // case surround
				area = AreaOfEffect.SURROUND;
				break;
			}

			switch (abilityDetails[0]) {
			case "CC":
				String effectName = abilityDetails[7];
				int effectDuration = Integer.parseInt(abilityDetails[8]);
				Effect eff;

				switch (effectName) {
				case "Disarm":
					eff = new Disarm(effectDuration);
					break;
				case "Dodge":
					eff = new Dodge(effectDuration);
					break;
				case "Embrace":
					eff = new Embrace(effectDuration);
					break;
				case "PowerUp":
					eff = new PowerUp(effectDuration);
					break;
				case "Root":
					eff = new Root(effectDuration);
					break;
				case "Shield":
					eff = new Shield(effectDuration);
					break;
				case "Shock":
					eff = new Shock(effectDuration);
					break;
				case "Silence":
					eff = new Silence(effectDuration);
					break;
				case "SpeedUp":
					eff = new SpeedUp(effectDuration);
					break;
				default: // Case stun
					eff = new Stun(effectDuration);
					break;
				}

				ab = new CrowdControlAbility(name, manaCost, baseCooldown, castRange, area, required, eff);
				break;
			case "DMG":
				int damageAmount = Integer.parseInt(abilityDetails[7]);
				ab = new DamagingAbility(name, manaCost, baseCooldown, castRange, area, required, damageAmount);
				break;
			case "HEL":
				int healingAmount = Integer.parseInt(abilityDetails[7]);
				ab = new HealingAbility(name, manaCost, baseCooldown, castRange, area, required, healingAmount);
				break;
			}
			availableAbilities.add(ab);
			s = br.readLine();
		}
		
		br.close();
	}
	
	public ArrayList<Cover> getCovers() { 
		return this.coversOnBoard;
	}

	public static void loadChampions(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String s = br.readLine();

		while (s != null)
		{
			String[] abilityDetails = s.split(",");
			String name = abilityDetails[1];
			int maxHP = Integer.parseInt(abilityDetails[2]);
			int mana = Integer.parseInt(abilityDetails[3]);
			int maxActions = Integer.parseInt(abilityDetails[4]);
			int speed = Integer.parseInt(abilityDetails[5]);
			int attackRange = Integer.parseInt(abilityDetails[6]);
			int attackDamage = Integer.parseInt(abilityDetails[7]);
			ArrayList<Ability> abilities = new ArrayList<Ability>();
			
			for (int j = 0; j < 3; j++) {
				String abilityName = abilityDetails[j + 8];
				for (int i = 0; i < availableAbilities.size(); i++) {
					Ability a = availableAbilities.get(i);
					if (a.getName().equals(abilityName)) {
						abilities.add(a);
					}
				}
			}
			
			Champion champ;
			switch (abilityDetails[0]) {
			case "A":
				champ = new AntiHero(name, maxHP, mana, maxActions, speed, attackRange, attackDamage);
				break;
			case "H":
				champ = new Hero(name, maxHP, mana, maxActions, speed, attackRange, attackDamage);
				break;
			default: // case V
				champ = new Villain(name, maxHP, mana, maxActions, speed, attackRange, attackDamage);
				break;
			}
			for (int z = 0; z < abilities.size(); z++) {
				champ.getAbilities().add(abilities.get(z));
			}
			availableChampions.add(champ);
			s = br.readLine();
		}
		br.close();
	}

	public boolean isFirstLeaderAbilityUsed() {
		return firstLeaderAbilityUsed;
	}

	public boolean isSecondLeaderAbilityUsed() {
		return secondLeaderAbilityUsed;
	}
	
	public Object[][] getBoard() {
		return board;
	}

	public int getBoardwidth() {
		return BOARDWIDTH;
	}

	public int getBoardheight() {
		return BOARDHEIGHT;
	}

	public Player getFirstPlayer() {
		return firstPlayer;
	}

	public Player getSecondPlayer() {
		return secondPlayer;
	}

	public PriorityQueue getTurnOrder() {
		return turnOrder;
	}

	public ArrayList<Ability> getAvailableAbilities() {
		return availableAbilities;
	}
	
	public ArrayList<Champion> getAvailableChampions() {
		return availableChampions;
	}
	
	public Champion getCurrentChampion() {
		return (Champion) this.turnOrder.peekMin();
	}
	
	public Player checkGameOver() {
		ArrayList<Champion> team1 = this.firstPlayer.getTeam();
		ArrayList<Champion> team2 = this.secondPlayer.getTeam();
		boolean firstTeamDead = true;
		boolean secondTeamDead = true;
		for(int i=0;i<team1.size();i++) {
			Champion currChampT1 = team1.get(i);
			if(currChampT1.getCurrentHP() != 0) {
				firstTeamDead = false;
			}
		}
		
		for(int i=0;i<team2.size();i++) {
			Champion currChampT2 = team2.get(i);
			if(currChampT2.getCurrentHP() != 0) {
				secondTeamDead = false;
			}
		}
		
		if(firstTeamDead) return this.secondPlayer;
		if(secondTeamDead) return this.firstPlayer;
		return null;
	}
	
	public void move(Direction d) throws UnallowedMovementException, NotEnoughResourcesException{
		Champion currChampion = this.getCurrentChampion();
		int actionPts = currChampion.getCurrentActionPoints();
		ArrayList<Effect> appliedEffects = currChampion.getAppliedEffects();
		for(int i=0;i<appliedEffects.size();i++) {
			if(appliedEffects.get(i) instanceof Root) {
				throw new UnallowedMovementException(currChampion.getName() + " is rooted, movement isn't possible.");
			}
		}
		if(actionPts > 0) {
			currChampion.setCurrentActionPoints(actionPts - 1);
			Point currLocation = currChampion.getLocation();
			int currX = currLocation.x;
			int currY = currLocation.y;

			if(d == Direction.UP) {
				if(currX + 1 < 5 && board[currX+1][currY] == null) {
					currChampion.getLocation().move(currX + 1, currY);
					board[currX+1][currY] = currChampion;
					board[currX][currY] = null;
				} else {
					throw new UnallowedMovementException("Can't move to a non-empty cell.");
				}
			} else if(d == Direction.DOWN) {
				if(currX - 1 >= 0 && board[currX-1][currY] == null) {
					currChampion.getLocation().move(currX - 1, currY);
					board[currX-1][currY] = currChampion;
					board[currX][currY] = null;
				} else {
					throw new UnallowedMovementException("Can't move to a non-empty cell.");
				}
			} else if(d == Direction.RIGHT) {
				if(currY + 1 < 5 && board[currX][currY+1] == null) {
					currChampion.getLocation().move(currX, currY+1);
					board[currX][currY+1] = currChampion;
					board[currX][currY] = null;
				} else {
					throw new UnallowedMovementException("Can't move to a non-empty cell.");
				}
			} else if(d == Direction.LEFT) {
				if(currY - 1 >= 0 && board[currX][currY-1] == null) {
					currChampion.getLocation().move(currX, currY-1);
					board[currX][currY-1] = currChampion;
					board[currX][currY] = null;
				} else {
					throw new UnallowedMovementException("Can't move to a non-empty cell.");
				}
			}
		} else {
			throw new NotEnoughResourcesException("You don't have enough action points to move, press E to end your turn.");
		}
	}
	
	public void attack(Direction d) throws ChampionDisarmedException, NotEnoughResourcesException {
		Champion currChamp = this.getCurrentChampion();
		int attackRange = currChamp.getAttackRange();
		Point currChampPos = currChamp.getLocation();
		Point lookRange;
		Damageable Target = null;
		
		if(currChamp.getCurrentActionPoints() < 2) {
			throw new NotEnoughResourcesException("You don't have enough action points to attack, press E to end your turn.");
		} else {
			currChamp.setCurrentActionPoints(currChamp.getCurrentActionPoints() - 2);
		}
		
		for(int i=1;i<=attackRange;i++) {
			if(d == Direction.UP) {
				lookRange = new Point(currChampPos.x + i, currChampPos.y);
			} else if(d == Direction.DOWN) {
				lookRange = new Point(currChampPos.x - i, currChampPos.y);
			} else if(d == Direction.LEFT) {
				lookRange = new Point(currChampPos.x, currChampPos.y - i);
			} else {
				lookRange = new Point(currChampPos.x, currChampPos.y + i);
			}
			
			if(lookRange.x >= Game.BOARDHEIGHT || lookRange.y >= Game.BOARDWIDTH || lookRange.x < 0 || lookRange.y < 0) {
				return;
			}
			
			if(this.board[lookRange.x][lookRange.y] != null) {
				Target = (Damageable) this.board[lookRange.x][lookRange.y];
				break;
			}
		}
		
		if(Target == null) return;
		
		ArrayList<Effect> currChampEffects = currChamp.getAppliedEffects();
		int currChampEffectsLen = currChampEffects.size();
		for(int i=0;i<currChampEffectsLen;i++) {
			Effect effApplied = currChampEffects.get(i);
			if(effApplied instanceof Disarm) {
				if(effApplied.getDuration() == 1) {
					currChamp.getAppliedEffects().remove(i);
					effApplied.remove(currChamp);
					i-=1; // effApplied getting modified
					currChampEffectsLen-=1;
				} else {
					effApplied.setDuration(effApplied.getDuration() - 1);
				}
				throw new ChampionDisarmedException("Champion is disarmed!");
			}
		}
		
		if(Target instanceof Champion) {
			Champion enemyChamp = (Champion) Target;
			ArrayList<Effect> enemyEffects = ((Champion) Target).getAppliedEffects();
			int enemyEffectsLen = enemyEffects.size();
			for(int i=0;i<enemyEffectsLen;i++) {
				Effect effApplied = enemyEffects.get(i);
				
				if(effApplied instanceof Shield) {
						enemyChamp.getAppliedEffects().remove(effApplied);
						effApplied.remove(enemyChamp);
						
						i-=1;
						enemyEffectsLen-=1;
						return;
				} else if(effApplied instanceof Dodge) {
					/*if(effApplied.getDuration() == 1) {
						effApplied.remove(enemyChamp);
						i-=1;
						enemyEffectsLen-=1;
						enemyChamp.getAppliedEffects().remove(i+1);
					} else {
						effApplied.setDuration(effApplied.getDuration() - 1);
					}*/
					
					Random rnd = new Random();
					int random = rnd.nextInt(2);
					if(random == 1)
					{
						return;
					}
				}
			}
		}
		
		this.championFight(currChamp, Target);
		
		if(Target.getCurrentHP() == 0) {
			ArrayList<Champion> team1 = this.firstPlayer.getTeam();
			ArrayList<Champion> team2 = this.secondPlayer.getTeam();
			if(team1.contains(Target)) {
				board[Target.getLocation().x][Target.getLocation().y] = null;
				team1.remove(Target);
			} else if(team2.contains(Target)) {
				board[Target.getLocation().x][Target.getLocation().y] = null;
				team2.remove(Target);
			} else {
				board[Target.getLocation().x][Target.getLocation().y] = null;
			}
			PriorityQueue temp = new PriorityQueue(turnOrder.size());
			while(!turnOrder.isEmpty()){
				if(turnOrder.peekMin()==Target){
					turnOrder.remove();
				}else{
					temp.insert(turnOrder.remove());
				}}
			while(!temp.isEmpty()){
				turnOrder.insert(temp.remove());
				
				
			}
		}
	}
	
	private ArrayList<ArrayList<Champion>> getCurrentChampionTeam() {
		ArrayList<ArrayList<Champion>> teamOrder = new ArrayList<ArrayList<Champion>>();
		if(this.firstPlayer.getTeam().contains(getCurrentChampion())) {
			teamOrder.add(this.firstPlayer.getTeam());
			teamOrder.add(this.secondPlayer.getTeam());
			return teamOrder;
		}
		teamOrder.add(this.secondPlayer.getTeam());
		teamOrder.add(this.firstPlayer.getTeam());
		return teamOrder;
	}
	
	private void championFight(Champion attacker, Damageable target) {
		int dmgAmount = attacker.getAttackDamage();
		if((attacker instanceof Hero && target instanceof Villain) || (attacker instanceof Villain && target instanceof Hero)) {
			dmgAmount = (int) (1.5 * dmgAmount);
			System.out.println(target.getCurrentHP() - dmgAmount);
		} else if(attacker instanceof AntiHero && (target instanceof Hero || target instanceof Villain)) {
			System.out.println(target.getCurrentHP() - dmgAmount);
			dmgAmount = (int) (1.5 * dmgAmount);
		} else if(target instanceof AntiHero && (attacker instanceof Hero || attacker instanceof Villain)) {
			System.out.println(target.getCurrentHP() - dmgAmount);
			dmgAmount = (int) (1.5 * dmgAmount);
		}
		
		target.setCurrentHP(target.getCurrentHP() - dmgAmount);
	}
	
	// add mana cost
	public void castAbility(Ability a) throws CloneNotSupportedException, NotEnoughResourcesException , AbilityUseException, InvalidTargetException{
		Champion currChamp = this.getCurrentChampion();
		//int castRange = a.getCastRange();
		ArrayList<Damageable> me = new ArrayList<Damageable>();
		if(currChamp.getCurrentActionPoints()<a.getRequiredActionPoints()) {
			throw new NotEnoughResourcesException("You don't have enough action points to do that, press E to end your turn!");
		} else if(currChamp.getMana()<a.getManaCost()) {
			throw new NotEnoughResourcesException("You don't have enough mana to do that, press E to end your turn!");
		}
		
		//currChamp.setCurrentActionPoints(currChamp.getCurrentActionPoints()-a.getRequiredActionPoints());
		//currChamp.setMana(currChamp.getMana()-a.getManaCost());
		
		
		if(a.getCurrentCooldown()!=0)
			throw new AbilityUseException("Can't use this ability, it's on cool down for " + a.getCurrentCooldown() + " more turns.");
		ArrayList<Effect> eff = currChamp.getAppliedEffects();
		for(int i=0;i<eff.size();i++) {
			if(eff.get(i) instanceof Silence)
				throw new AbilityUseException("Champion is silenced, can't use ability.");
		}
		// ability is SELFTARGET, SURROUND, TEAMTARGET
		if(a.getCastArea() == AreaOfEffect.SELFTARGET)
		{ 
			me.add(currChamp);
			a.execute(me);
		} else if(a.getCastArea() == AreaOfEffect.SURROUND) {
			Point location = currChamp.getLocation();
			ArrayList<Damageable> surrounding = new ArrayList<>();
			int x = (int) location.getX();
			int y = (int) location.getY();
			ArrayList<Champion> enemies = this.getCurrentChampionTeam().get(1);
		    ArrayList<Champion> allied = this.getCurrentChampionTeam().get(0);
			if (x + 1 <= 4 && board[x + 1][y] != null) {
				surrounding.add((Damageable) board[x + 1][y]);
		}
		
		
		if (x + 1 <= 4 && y + 1 <= 4 && board[x + 1][y + 1] != null) {
			surrounding.add((Damageable) board[x + 1][y + 1]);
		}
		if (x + 1 <= 4 && y - 1 >= 0 && board[x + 1][y - 1] != null) {
			surrounding.add((Damageable) board[x + 1][y - 1]);
		}
		if (y + 1 <= 4 && board[x][y + 1] != null) {
			surrounding.add((Damageable) board[x][y + 1]);
		}
		if (y - 1 >= 0 && board[x][y - 1] != null) {
			surrounding.add((Damageable) board[x][y - 1]);
		}
		if (x - 1 >= 0 && board[x - 1][y] != null) {
			surrounding.add((Damageable) board[x - 1][y]);
		}
		
		if (x - 1 >= 0 && y - 1 >= 0 && board[x - 1][y - 1] != null) {
			surrounding.add((Damageable) board[x - 1][y - 1]);

		}
		if (x - 1 >= 0 && y + 1 <= 4 && board[x - 1][y + 1] != null) {
			surrounding.add((Damageable) board[x - 1][y + 1]);
		}

		ArrayList<Damageable> applied = new ArrayList<>();
		if (a instanceof HealingAbility) {
			for (int i = 0; i < surrounding.size(); i++) {
				if (allied.contains(surrounding.get(i))) {
					applied.add(surrounding.get(i));
				}
			}
			((HealingAbility) a).execute(applied);
		}
		if (a instanceof DamagingAbility) {
			for (int i = 0; i < surrounding.size(); i++) {
				if (!(allied.contains(surrounding.get(i)))) {
					applied.add(surrounding.get(i));
				}
			}
			for (int j = 0; j < applied.size(); j++) {
				if (applied.get(j) instanceof Champion) {
					ArrayList<Effect> enemyeffs = ((Champion) applied.get(j)).getAppliedEffects();
					for (int i = 0; i < enemyeffs.size(); i++) {
						if (enemyeffs.get(i) instanceof Shield) {
							enemyeffs.get(i).remove((Champion) applied.get(j));
							enemyeffs.remove(i);
							applied.remove(j);
							i--;
							break;
						}
					}

				}
			}

			((DamagingAbility) a).execute(applied);
			
			

			for (int i = 0; i < applied.size(); i++) {
				if (applied.get(i).getCurrentHP() <= 0) {
					this.removeDead(applied);
					board[applied.get(i).getLocation().x][applied.get(i).getLocation().y] = null;
					PriorityQueue temp = new PriorityQueue(6);
					while (!turnOrder.isEmpty()) {
						if (turnOrder.peekMin() == applied.get(i))
							turnOrder.remove();
						else
							temp.insert(turnOrder.remove());
					}
					while (!temp.isEmpty()) {
						turnOrder.insert(temp.remove());
					}

				}
			}

		}
		if (a instanceof CrowdControlAbility) {
			if (((CrowdControlAbility) a).getEffect().getType().equals(EffectType.BUFF)) {
				for (int i = 0; i < surrounding.size(); i++) {
					if (allied.contains(surrounding.get(i))) {
						applied.add(surrounding.get(i));
					}
				}
				((CrowdControlAbility) a).execute(applied);
			} else {
				for (int i = 0; i < surrounding.size(); i++) {
					if (enemies.contains(surrounding.get(i))) {
						applied.add(surrounding.get(i));
					}
				}
				((CrowdControlAbility) a).execute(applied);
			}
		}
		} else if(a.getCastArea() == AreaOfEffect.TEAMTARGET) {
			ArrayList<Champion> allied = this.getCurrentChampionTeam().get(0);
			ArrayList<Champion> enemies = this.getCurrentChampionTeam().get(1);
			//ArrayList<Cover> covers = this.coversOnBoard;
			int alliedSize = allied.size();
			int enemySize = enemies.size();
			//int coversSize = covers.size();
			
			if(a instanceof HealingAbility) {
				ArrayList<Damageable> applied = new ArrayList<Damageable>();
				for(int i=0;i<alliedSize;i++) {
					Champion ally = (Champion) allied.get(i);

						if(this.getManhattanDistance(ally.getLocation(), currChamp.getLocation()) <= a.getCastRange()) {
							applied.add(ally);
					}
				}
				a.execute(applied);
			}
			
			if(a instanceof DamagingAbility) {
				ArrayList<Damageable> applied = new ArrayList<Damageable>();
				for(int i=0;i<enemySize;i++) {
					Champion enemy = (Champion) enemies.get(i);
					if(this.getManhattanDistance(enemy.getLocation(), currChamp.getLocation()) <= a.getCastRange()) {
						applied.add(enemy);
					}
				}for (int j = 0; j < applied.size(); j++) {
					if (applied.get(j) instanceof Champion) {
						ArrayList<Effect> enemyeffs = ((Champion) applied.get(j)).getAppliedEffects();
						for (int i = 0; i < enemyeffs.size(); i++) {
							if (enemyeffs.get(i) instanceof Shield) {
								enemyeffs.get(i).remove((Champion) applied.get(j));
								enemyeffs.remove(i);
								applied.remove(j);
								i--;
								break;
							}
						}

					}
				}
				a.execute(applied);
				this.removeDead(applied);
				for (int i = 0; i < applied.size(); i++) {
					if (applied.get(i).getCurrentHP() <= 0) {
						this.removeDead(applied);
						board[applied.get(i).getLocation().x][applied.get(i).getLocation().y] = null;
						PriorityQueue temp = new PriorityQueue(6);
						while (!turnOrder.isEmpty()) {
							if (turnOrder.peekMin() == applied.get(i))
								turnOrder.remove();
							else
								temp.insert(turnOrder.remove());
						}
						while (!temp.isEmpty()) {
							turnOrder.insert(temp.remove());
						}

					}
				}
			}
			
			if(a instanceof CrowdControlAbility) {
				CrowdControlAbility ability = (CrowdControlAbility) a;
				if(ability.getEffect().getType() == EffectType.DEBUFF) {
					// enemy
					ArrayList<Damageable> applied = new ArrayList<Damageable>();
					for(int i=0;i<enemySize;i++) {
						Champion enemy = (Champion) enemies.get(i);
						if(this.getManhattanDistance(enemy.getLocation(), currChamp.getLocation()) <= a.getCastRange()) {
							applied.add(enemy);
						}
					}
					a.execute(applied);
				} else {
					// ally
					ArrayList<Damageable> applied = new ArrayList<Damageable>();
					for(int i=0;i<alliedSize;i++) {
						Champion ally = (Champion) allied.get(i);
							if(this.getManhattanDistance(ally.getLocation(), currChamp.getLocation()) <= a.getCastRange()) {
								applied.add(ally);
				
						}
					}
					 a.execute(applied);
				}
			}
		}
		a.setCurrentCooldown(a.getBaseCooldown());
		currChamp.setCurrentActionPoints(currChamp.getCurrentActionPoints() - a.getRequiredActionPoints());
		currChamp.setMana(currChamp.getMana() - a.getManaCost());
	}
	
	public void castAbility(Ability a, Direction d) throws CloneNotSupportedException, NotEnoughResourcesException, AbilityUseException {
		Champion currChamp = this.getCurrentChampion();
		ArrayList<Damageable> affectedEnemies = new ArrayList<Damageable>();
		ArrayList<Damageable> affectedAllies = new ArrayList<Damageable>();
		ArrayList<Damageable> affectedCovers = new ArrayList<Damageable>();
		
		ArrayList<Champion> allies = this.getCurrentChampionTeam().get(0);
		//ArrayList<Champion> enemies = this.getCurrentChampionTeam().get(1);
		ArrayList<Effect> eff = this.getCurrentChampion().getAppliedEffects();
		if(a.getCurrentCooldown()!=0)
			throw new AbilityUseException("Can't use this ability, it's on cool down for " + a.getCurrentCooldown() + " more turns.");
		for(int i=0;i<eff.size();i++) {
			if(eff.get(i) instanceof Silence)
				throw new AbilityUseException("Champion is silenced, can't use ability.");
		}
		
		if(currChamp.getCurrentActionPoints()<a.getRequiredActionPoints()) {
			throw new NotEnoughResourcesException("You don't have enough action points to do that, press E to end your turn!");
		} else if(currChamp.getMana()<a.getManaCost()) {
			throw new NotEnoughResourcesException("You don't have enough mana to do that, press E to end your turn!");
		}
		//currChamp.setMana(currChamp.getMana()-a.getManaCost());
		
		
		Point currPosition = currChamp.getLocation();
		int newX=0;
		int newY=0;
		for(int i=1;i<=a.getCastRange();i++) {
			if(d == Direction.UP) {
				newX = currPosition.x + i;
				newY = currPosition.y ;
			} else if(d == Direction.DOWN) {
				newX = currPosition.x - i ;
				newY = currPosition.y;
			} else if(d == Direction.LEFT) {
				newX = currPosition.x;
				newY = currPosition.y - i;
			} else if(d == Direction.RIGHT) {
				newX = currPosition.x;
				newY = currPosition.y + i;
			}
			
			if(newX < 5 && newY < 5 && newX >= 0 && newY >= 0) {
				if(this.board[newX][newY] != null) {
					Damageable obj = (Damageable) this.board[newX][newY];
					if(obj instanceof Champion) {
						if(allies.contains((Champion) obj)) {
							affectedAllies.add((Champion) obj);
						} else {
							if(!isShield((Champion)obj)){
							affectedEnemies.add((Champion) obj);}
							
						}
					} else if(obj instanceof Cover) {
						affectedCovers.add((Cover) obj);
					}
				}
			} else {
				break;
			}
		}

		if(a instanceof DamagingAbility) {
			DamagingAbility ability = (DamagingAbility) a;
			for (int j = 0; j < affectedEnemies.size(); j++) {
				if (affectedEnemies.get(j) instanceof Champion) {
					ArrayList<Effect> enemyeffs = ((Champion) affectedEnemies.get(j)).getAppliedEffects();
					for (int i = 0; i < enemyeffs.size(); i++) {
						if (enemyeffs.get(i) instanceof Shield) {
							enemyeffs.get(i).remove((Champion) affectedEnemies.get(j));
							enemyeffs.remove(i);
							affectedEnemies.remove(j);
							i--;
							break;
						}
					}

				}
			}
			
			ability.execute(affectedEnemies);
			this.removeDead(affectedEnemies);
			ability.execute(affectedCovers);
			for (int i = 0; i < affectedEnemies.size(); i++) {
				if (affectedEnemies.get(i).getCurrentHP() <= 0) {
					this.removeDead(affectedEnemies);
					board[affectedEnemies.get(i).getLocation().x][affectedEnemies.get(i).getLocation().y] = null;
					PriorityQueue temp = new PriorityQueue(6);
					while (!turnOrder.isEmpty()) {
						if (turnOrder.peekMin() == affectedEnemies.get(i))
							turnOrder.remove();
						else
							temp.insert(turnOrder.remove());
					}
					while (!temp.isEmpty()) {
						turnOrder.insert(temp.remove());
					}

				}
			}
		} else if(a instanceof CrowdControlAbility) {
			CrowdControlAbility ability = (CrowdControlAbility) a;
			if(ability.getEffect().getType() == EffectType.BUFF) {
				ability.execute(affectedAllies);
			} else {
				ability.execute(affectedCovers);
				ability.execute(affectedEnemies);
			}
		} else if(a instanceof HealingAbility) {
			HealingAbility ability = (HealingAbility) a;
			ability.execute(affectedAllies);
		}
		a.setCurrentCooldown(a.getBaseCooldown());
		currChamp.setMana(currChamp.getMana()-a.getManaCost());
		currChamp.setCurrentActionPoints(currChamp.getCurrentActionPoints() - a.getRequiredActionPoints());
	}
	
	public void castAbility(Ability a, int x, int y) throws InvalidTargetException,CloneNotSupportedException, NotEnoughResourcesException, AbilityUseException {
		Point p = new Point(x, y);
		Point p1 = this.getCurrentChampion().getLocation();
		Champion currChamp=this.getCurrentChampion();
		ArrayList<Effect> eff = this.getCurrentChampion().getAppliedEffects();
		for(int i=0;i<eff.size();i++) {
			if(eff.get(i) instanceof Silence)
				throw new AbilityUseException("Champion is silenced, can't use ability");
		}
		if(currChamp.getCurrentActionPoints()<a.getRequiredActionPoints()) {
			throw new NotEnoughResourcesException("You don't have enough action points to do that, press E to end your turn!");
		} else if(currChamp.getMana()<a.getManaCost()) {
			throw new NotEnoughResourcesException("You don't have enough mana to do that, press E to end your turn!");
		}
		if(a.getCurrentCooldown()!=0)
			throw new AbilityUseException("Can't use ability as it's on cool down for the next " + a.getCurrentCooldown() + " turns.");
		
		if(board[x][y] == null) throw new InvalidTargetException("Target cell is empty, can't cast ability on empty cell.");

		//currChamp.setMana(currChamp.getMana()-a.getManaCost());
		ArrayList<Damageable> affected_ = new ArrayList<Damageable>();
		
		if(this.getManhattanDistance(p, p1) <= a.getCastRange()) {
			this.getCurrentChampion().setCurrentActionPoints(this.getCurrentChampion().getCurrentActionPoints() - a.getRequiredActionPoints());
			ArrayList<Champion> allies = this.getCurrentChampionTeam().get(0);
			ArrayList<Champion> enemies = this.getCurrentChampionTeam().get(1);
			
			Damageable affected = (Damageable) this.board[x][y];
         
			if(a instanceof HealingAbility) {
				if(affected instanceof Champion) {
					Champion champ = (Champion) affected;
					if(!allies.contains(champ)) {
						throw new InvalidTargetException("Can't cast healing ability on an enemy.");
					}
				} else {
					throw new InvalidTargetException("Can't cast healing ability on a cover.");
				}
				if(affected instanceof Champion)
					affected_.add(affected);
				
			}
			else if(a instanceof DamagingAbility) {
				if(affected instanceof Champion) {
					Champion champ = (Champion) affected;
					if(!enemies.contains(champ) || board[x][y]==currChamp) {
						throw new InvalidTargetException("Can't cast damaging ability on an ally.");
					}
				}
				affected_.add(affected);
				if (affected instanceof Champion) {
					Champion champ = (Champion) affected;
					ArrayList<Effect> enemyeffs = champ.getAppliedEffects();
					for (int i = 0; i < enemyeffs.size(); i++) {
						if (enemyeffs.get(i) instanceof Shield) {
							enemyeffs.get(i).remove(champ);
							enemyeffs.remove(i);
							affected_.remove(champ);
							break;
						}
					}

				}
				
			} else if(a instanceof CrowdControlAbility) {
				CrowdControlAbility ability = (CrowdControlAbility) a;
				if(ability.getEffect().getType() == EffectType.BUFF) {
					if(affected instanceof Champion) {
						Champion champ = (Champion) affected;
						if(!allies.contains(champ)) {
							throw new InvalidTargetException("Can't cast BUFF type ability on enemy");
						}	
					} else {
						throw new InvalidTargetException("Can't cast crowd control ability on cover");
					}
					if(affected instanceof Champion) {
						affected_.add(affected);
							
					 }
				} else {
					if(affected instanceof Champion) {
						Champion champ = (Champion) affected;
						if(!enemies.contains(champ)) {
							throw new InvalidTargetException("Can't cast DEBUFF ability on ally");
						}
					} else {
						throw new InvalidTargetException("Can't cast crowd control ability on cover");
					}
					if(affected instanceof Champion) {
						affected_.add(affected);
						
					     }
					else
						throw new InvalidTargetException("Can't cast crowd control ability on cover");
				}
			} else {
				throw new InvalidTargetException("Invalid target.");
			}
			
			a.execute(affected_);
			for (int i = 0; i < affected_.size(); i++) {
				if (affected_.get(i).getCurrentHP() <= 0) {
					this.removeDead(affected_);
					board[affected_.get(i).getLocation().x][affected_.get(i).getLocation().y] = null;
					PriorityQueue temp = new PriorityQueue(6);
					while (!turnOrder.isEmpty()) {
						if (turnOrder.peekMin() == affected_.get(i))
							turnOrder.remove();
						else
							temp.insert(turnOrder.remove());
					}
					while (!temp.isEmpty()) {
						turnOrder.insert(temp.remove());
					}

				}
			}
			
			this.removeDead(affected_);
			
		} else {
			throw new AbilityUseException("Target out of range.");
		}
		a.setCurrentCooldown(a.getBaseCooldown());
		currChamp.setMana(currChamp.getMana()-a.getManaCost());
		
		
	}
	
	
	public void useLeaderAbility() throws LeaderAbilityAlreadyUsedException, LeaderNotCurrentException {
		Champion currChamp = this.getCurrentChampion();
		ArrayList<Champion> allies = this.getCurrentChampionTeam().get(0);
		ArrayList<Champion> enemies = this.getCurrentChampionTeam().get(1);
		// hero affects allied champs
		// villain affects enemy champs
		// antihero affects everyone except 2 leaders
		if(this.firstPlayer.getLeader() == currChamp || this.secondPlayer.getLeader() == currChamp) {
			if(this.firstPlayer.getLeader() == currChamp) {
				if(!this.firstLeaderAbilityUsed)
					this.firstLeaderAbilityUsed = true;
				else
					throw new LeaderAbilityAlreadyUsedException("Player 1 already used their leader ability.");
			}
			else {
				if(!this.secondLeaderAbilityUsed)
					this.secondLeaderAbilityUsed = true;
				else
					throw new LeaderAbilityAlreadyUsedException("Player 2 already used their leader ability.");
			}
			if(currChamp instanceof Hero) {
				Hero h = (Hero) currChamp;
				h.useLeaderAbility(allies);
			} else if(currChamp instanceof Villain) {
				Villain v = (Villain) currChamp;
				v.useLeaderAbility(enemies);
				for(int i = 0 ; i <enemies.size() ; i++) {
				  
					Champion enemyChamp = enemies.get(i);
					if(enemyChamp.getCurrentHP()<enemyChamp.getMaxHP()*0.3) {
						int x = enemyChamp.getLocation().x;
						int y = enemyChamp.getLocation().y;
						board[x][y] = null;
						enemies.remove(i--);
					}
				}
			} else {
				ArrayList<Champion> allChamps = new ArrayList<Champion>();
				for(int i=0;i<enemies.size();i++) {
					Champion champ = enemies.get(i);
					if(champ != this.firstPlayer.getLeader() && champ != this.secondPlayer.getLeader()) {
						allChamps.add(champ);
					}
				}
				
				for(int i=0;i<allies.size();i++) {
					Champion champ = allies.get(i);
					if(champ != this.firstPlayer.getLeader() && champ != this.secondPlayer.getLeader()) {
						allChamps.add(champ);
					}
				}
				
				AntiHero h = (AntiHero) currChamp;
				h.useLeaderAbility(allChamps);
			}
		} else {
			throw new LeaderNotCurrentException("It's not the leader's turn, can't use their ability.");
		}
		// dont forget use leader ability true
	}
	
	
	
	private int getManhattanDistance(Point a, Point b) {
		return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
	}
	
	public void endTurn() {
		if(!turnOrder.isEmpty()) {
			this.turnOrder.remove();
		} else {
			this.prepareChampionTurns();
			return;
		}
		if(this.turnOrder.isEmpty()) {
			this.prepareChampionTurns();
		} else {
			Champion currChamp = this.getCurrentChampion();
			while(currChamp.getCondition() == Condition.INACTIVE) {
				currChamp.setCurrentActionPoints(currChamp.getMaxActionPointsPerTurn());
				ArrayList<Effect> effects = currChamp.getAppliedEffects();
				for(int i=0;i<effects.size();i++) {
					Effect eff = effects.get(i);
					
					eff.setDuration(eff.getDuration() - 1);
					if(eff.getDuration() == 0) {
						currChamp.getAppliedEffects().remove(i--);
						eff.remove(currChamp);
					}
				}
				
				ArrayList<Ability> abilities = currChamp.getAbilities();
				
				for(int i=0; i<abilities.size();i++) {
					Ability a = abilities.get(i);
					
					if(a.getCurrentCooldown() > 0) {
						a.setCurrentCooldown(a.getCurrentCooldown() - 1);
					}
				}
				this.turnOrder.remove();
				if(this.turnOrder.isEmpty()) {
					this.prepareChampionTurns();
					return;
				}
				currChamp = this.getCurrentChampion();
			}
			
			currChamp.setCurrentActionPoints(currChamp.getMaxActionPointsPerTurn());
			ArrayList<Effect> effects = currChamp.getAppliedEffects();
			for(int i=0;i<effects.size();i++) {
				Effect eff = effects.get(i);
				
				eff.setDuration(eff.getDuration() - 1);
				if(eff.getDuration() == 0) {
					currChamp.getAppliedEffects().remove(i--);
					eff.remove(currChamp);
				}
			}
			
			ArrayList<Ability> abilities = currChamp.getAbilities();
			
			for(int i=0; i<abilities.size();i++) {
				Ability a = abilities.get(i);
				
				if(a.getCurrentCooldown() > 0) {
					a.setCurrentCooldown(a.getCurrentCooldown() - 1);
				}
			}
		}
		
		this.checkGameOver();
	}
	
	public void prepareChampionTurns() {
		ArrayList<Champion> team1 = this.firstPlayer.getTeam();
		ArrayList<Champion> team2 = this.secondPlayer.getTeam();
		
		
		
		for(int i=0;i<team1.size();i++) {
			//System.out.print("here");
			Champion x = (Champion) team1.get(i);
			if(x.getCurrentHP() != 0) {
				this.turnOrder.insert(x);
				x.setCurrentActionPoints(x.getMaxActionPointsPerTurn());
			}
			//System.out.println(bothTeams.get(i));
		}
		
		for(int i=0;i<team2.size();i++) {
			//System.out.print("here");
			Champion x = (Champion) team2.get(i);
			if(x.getCurrentHP() != 0) {
				this.turnOrder.insert(x);
				x.setCurrentActionPoints(x.getMaxActionPointsPerTurn());
			}
			//System.out.println(bothTeams.get(i));
		}		
	}
    public boolean isShield(Champion c) {
    	boolean flag=false;
    	ArrayList<Effect> x = c.getAppliedEffects();
    	for(int i=0;i<x.size();i++) {
    		if(x.get(i).getName()=="Shield")
    			flag=true;
    	}
    	return flag;
    }
    public void removeDead(ArrayList<Damageable> x) {
    	
    	    ArrayList<Champion> team1 = this.firstPlayer.getTeam();
    	    ArrayList<Champion> team2 = this.secondPlayer.getTeam();
    	    for(int i=0;i<x.size();i++) {
    	    	Damageable curr = x.get(i);
    	    	Point p = curr.getLocation();
	    	    if(curr.getCurrentHP()==0) {
					if(team1.contains(curr)) {
						team1.remove(curr);
						board[p.x][p.y]=null;
					}
					else if(team2.contains(curr)) {
						team2.remove(curr);
						board[p.x][p.y]=null;
					} else {
						board[p.x][p.y]=null;
					}
	    	    }
    	    }
    	    
    		
    }
	
}
