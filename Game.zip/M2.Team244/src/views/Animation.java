package views;

import java.awt.Color;
import java.awt.Panel;
import java.util.HashMap;






import javax.swing.BorderFactory;
import javax.swing.JPanel;

import model.world.Champion;
import engine.Game;

public class Animation extends Thread {
	Game g;
	HashMap<Champion, JPanel> championsPanels;
	public Animation(Game g, HashMap<Champion, JPanel> championsPanels) {
		this.g = g;
		this.championsPanels = championsPanels;
	}
	public void run() {
		while(true){
			boolean t = true;
			Champion c = g.getCurrentChampion();
			JPanel p = championsPanels.get(c);

			for(int i=0;i<2;i++) {
				if(t) {
					p.setBorder(BorderFactory.createLineBorder(Color.green, 3));
					t=false;
				}
				else {
					p.setBorder(BorderFactory.createLineBorder(
							(g.getFirstPlayer().getTeam().contains(c)) ? Color.blue : Color.red
							, 3));
			    	t=true;
				}
					
		    	try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	
			}
		}
	}

}
