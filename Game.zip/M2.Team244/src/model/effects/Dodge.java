package model.effects;

import model.world.Champion;

public class Dodge extends Effect {
	public Dodge(int duration) {
		super("Dodge",duration,EffectType.BUFF);
	}

	@Override
	public void apply(Champion C) {
		int newSpeed = (int)(C.getSpeed() * 1.05);
		C.setSpeed(newSpeed);
		
	}

	@Override
	public void remove(Champion C) {
		// TODO Auto-generated method stub
		C.setSpeed((int) (C.getSpeed() / 1.05));
	}
}
