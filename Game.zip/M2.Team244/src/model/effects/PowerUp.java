package model.effects;

import java.util.ArrayList;

import model.abilities.Ability;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.Champion;

public class PowerUp extends Effect {
	private int oldDamageAmount;
	private int healAmount;
	public PowerUp(int duration) {
		super("PowerUp",duration,EffectType.BUFF);
	}

	@Override
	public void apply(Champion C){
		// TODO Auto-generated method stub
		ArrayList<Ability> championAbilities = C.getAbilities();
		for(int i=0;i<championAbilities.size();i++) {
			Ability currentAbility = championAbilities.get(i);
			if(currentAbility instanceof HealingAbility) {
				HealingAbility currentAbility_ = (HealingAbility) currentAbility;
				int newHealing = (int) (currentAbility_.getHealAmount() * 1.2);
				currentAbility_.setHealAmount(newHealing);
			} else if(currentAbility instanceof DamagingAbility) {
				DamagingAbility currentAbility_ = (DamagingAbility) currentAbility;
				int newHealing = (int) (currentAbility_.getDamageAmount() * 1.2);
				currentAbility_.setDamageAmount(newHealing);
			}
		}
	}

	@Override
	public void remove(Champion C) {
		ArrayList<Ability> championAbilities = C.getAbilities();
		for(int i=0;i<championAbilities.size();i++) {
			Ability currentAbility = championAbilities.get(i);
			if(currentAbility instanceof HealingAbility) {
				HealingAbility currentAbility_ = (HealingAbility) currentAbility;
				int newHealing = (int) (currentAbility_.getHealAmount() / 1.2);
				currentAbility_.setHealAmount(newHealing);
			} else if(currentAbility instanceof DamagingAbility) {
				DamagingAbility currentAbility_ = (DamagingAbility) currentAbility;
				int newHealing = (int) (currentAbility_.getDamageAmount() / 1.2);
				currentAbility_.setDamageAmount(newHealing);
			}
		}
	}
}
