package exceptions;

public class AbilityUseException extends GameActionException {
	public AbilityUseException() {

	}

	public AbilityUseException(String s) {
		super(s);
	}
}
