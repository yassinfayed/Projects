package views;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.URL;

import engine.*;

import javax.swing.*;

public class GameStart {
    public static void main(String args[]){
        JFrame frame = new JFrame("Marvel Heroes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300,200);
        frame.setLocationRelativeTo(null);


        JTextField player1Name = new JTextField();
        //player1Name.setBounds(600, 400, 200, 50);
        Font f = new Font("SansSerif", Font.PLAIN, 20);        
        JTextField player2Name = new JTextField();
        //player2Name.setBounds(600, 450, 200, 50);
        
        player1Name.setFont(f);
        player2Name.setFont(f);
        
        JLabel player1NameLabel = new JLabel();
        player1NameLabel.setText("Player 1 Name");
        player1NameLabel.setFont(f);
        //player1NameLabel.setBounds(200,400,500,50);
        
        
        JLabel player2NameLabel = new JLabel();
        player2NameLabel.setText("Player 2 Name");
        player2NameLabel.setFont(f);
        //player2NameLabel.setBounds(200,450,500,50);
        
        
        
        JButton setNames = new JButton();
        setNames.setText("PLAY");
        setNames.setFont(f);
        
        JButton exit = new JButton();
        exit.setText("EXIT");
        exit.setFont(f);
        
        exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}});
        
        Cursor c = new Cursor(Cursor.HAND_CURSOR);
        
        setNames.setCursor(c);
        setNames.setFocusPainted(false);
        setNames.setContentAreaFilled(false);
        
        exit.setCursor(c);
        exit.setFocusPainted(false);
        exit.setContentAreaFilled(false);
        
        frame.setLayout(new GridLayout(3,2));

        frame.add(player1NameLabel);
        frame.add(player1Name);
        
        frame.add(player2NameLabel);
        frame.add(player2Name);
        frame.add(setNames);
        frame.add(exit);
        
        
        
        setNames.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				System.out.println(System.getProperty("user.dir"));
				frame.dispose();
            	try {
					new ChampionSelection(player1Name.getText(), player2Name.getText());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}	
        });
        
        frame.setVisible(true);
     }
    

}
