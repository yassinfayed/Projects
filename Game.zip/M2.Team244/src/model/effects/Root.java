package model.effects;

import java.util.ArrayList;

import model.world.Champion;
import model.world.Condition;

public class Root extends Effect {
	private int oldSpeed;
	public Root(int duration) {
		super("Root", duration, EffectType.DEBUFF);
	}

	@Override
	public void apply(Champion C) {
		if(C.getCondition() != Condition.INACTIVE)
			C.setCondition(Condition.ROOTED);
	}

	@Override
	public void remove(Champion C) {
		// TODO Auto-generated method stub
		ArrayList<Effect> effects = C.getAppliedEffects();
		for(int i=0;i<effects.size();i++) {
			if(effects.get(i) instanceof Root) {
				return;
			}
		}
		if(C.getCondition() == Condition.ROOTED)
			C.setCondition(Condition.ACTIVE);
	}
}
