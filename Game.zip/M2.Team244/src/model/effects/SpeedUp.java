package model.effects;

import model.world.Champion;

public class SpeedUp extends Effect {
	public SpeedUp(int duration) {
		super("SpeedUp", duration, EffectType.BUFF);
	}

	@Override
	public void apply(Champion C) {
		C.setSpeed((int) (C.getSpeed() * 1.15));
		C.setMaxActionPointsPerTurn(C.getMaxActionPointsPerTurn() + 1);
		C.setCurrentActionPoints(C.getCurrentActionPoints() + 1);
	}

	@Override
	public void remove(Champion C) {
		C.setSpeed((int) (C.getSpeed() / 1.15));
		C.setMaxActionPointsPerTurn(C.getMaxActionPointsPerTurn() - 1);
		C.setCurrentActionPoints(C.getCurrentActionPoints() - 1);
	}
}
