package views;
//lll
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
//import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.*;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.effects.EffectType;
import model.world.Champion;
import model.world.Cover;
import model.world.Damageable;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;
import engine.Game;
import engine.Player;
import exceptions.GameActionException;

public class PlayPhase implements KeyListener {
	JFrame frame;
	Game gameInstance;
	
	Map<Champion, JPanel> playerOneChampionsPanels = new HashMap<Champion, JPanel>();
	Map<Champion, JPanel> playerTwoChampionsPanels = new HashMap<Champion, JPanel>();
	Map<Cover, JPanel> coversPanels = new HashMap<Cover, JPanel>();
	Map<Damageable, JProgressBar> healthBars = new HashMap<Damageable, JProgressBar>();
	Map<Champion, JButton> leaderAbilityIndicators = new HashMap<Champion, JButton>();
	ArrayList<Champion> teamOneChampions;
	ArrayList<Champion> teamTwoChampions;
	ArrayList<Cover> covers;
	JLabel shownDetails;
	JPanel shownDetailsPanel;
	
	Component[][] grid = new Component[5][5];
	JPanel boardPanel = new JPanel();
	Font f;
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    
    Ability currAbility;
    AreaOfEffect abilityType;
	Color c3 = new Color(40, 40, 40);
	Color COL_HIGHLIGHT = new Color(10, 130, 10);
	
	public PlayPhase(Game gameInstance) {
    	UIManager.put("ProgressBar.selectionBackground", Color.black);
        UIManager.put("ProgressBar.selectionForeground", Color.white);
        UIManager.put("ProgressBar.foreground", new Color(8, 32, 128));
        UIManager.put("Panel.background", c3);
        UIManager.put("Label.foreground", Color.white);
        UIManager.put("List.background", new Color(35,35,35));
        UIManager.put("List.foreground", Color.white);
        UIManager.put("OptionPane.foreground", Color.white);
        UIManager.put("OptionPane.background", c3);
        UIManager.put("Button.foreground", Color.white);

        
		this.gameInstance = gameInstance;
		ToolTipManager.sharedInstance().setDismissDelay(9999);
		
        frame = new JFrame("Marvel Heroes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(screenSize.width, 1000);
        frame.setFocusable(true);
		frame.getContentPane().setBackground(new Color(40, 40, 40));

        // frame.setLayout();

        this.shownDetails = new JLabel();
        this.frame.setLayout(new BorderLayout());
        this.frame.setVisible(true);
        this.frame.addKeyListener(this);
        frame.setLocationRelativeTo(null);

        
        boardPanel.setLayout(new GridLayout(5,5));
        boardPanel.setSize(1000, 900);
    	boardPanel.setBorder(BorderFactory.createLineBorder(Color.black));
    	boardPanel.setFocusable(false);
    	
        this.frame.add(BorderLayout.WEST, boardPanel);


        this.loadInfo();
        this.f = new Font("SansSerif", Font.PLAIN, 60);
	}
	
	JList<String> turnOrderBox;
	private void loadInfo() {
		this.gameInstance.placeChampions();
		this.gameInstance.prepareChampionTurns();
		
		this.teamOneChampions = this.gameInstance.getFirstPlayer().getTeam();
		this.teamTwoChampions = this.gameInstance.getSecondPlayer().getTeam();
		this.covers = this.gameInstance.getCovers();
		
		this.teamPanels(teamOneChampions, this.playerOneChampionsPanels);
		this.teamPanels(teamTwoChampions, this.playerTwoChampionsPanels);
		this.coverPanels(covers, this.coversPanels);
		
		this.updateBoard();
		HashMap<Champion, JPanel> totPanels = new HashMap<Champion, JPanel>();
		totPanels.putAll(this.playerOneChampionsPanels);
		totPanels.putAll(this.playerTwoChampionsPanels);
		Animation ani = new Animation(this.gameInstance, totPanels);
		ani.start();
		
		JPanel infoPanel = new JPanel();

		infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
		infoPanel.setPreferredSize(new Dimension(screenSize.width - 1000, 900));
		infoPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		
		
		JPanel panel1Info = new JPanel();

		panel1Info.setLayout(new BoxLayout(panel1Info, BoxLayout.Y_AXIS));
		
		JLabel playerNames = new JLabel("<html><h1><center><p style='color:blue;'>PLAYER 1: "+this.gameInstance.getFirstPlayer().getName().toUpperCase()+"</p><p style='color:red;'>PLAYER 2: "+this.gameInstance.getSecondPlayer().getName().toUpperCase()+"</span></center></p></html>", SwingConstants.CENTER);
		
		
		turnOrderBox = new JList<String>();
		turnOrderBox.setBorder(BorderFactory.createEmptyBorder(10, 10,10,10));
		turnOrderBox.setFixedCellWidth(screenSize.width - 1000);
		turnOrderBox.setFixedCellHeight(20);
		DefaultListCellRenderer renderer = (DefaultListCellRenderer) turnOrderBox.getCellRenderer();
		renderer.setHorizontalAlignment(SwingConstants.CENTER);

		shownDetails = new JLabel("", SwingConstants.CENTER);
		shownDetailsPanel = new JPanel();
		shownDetailsPanel.setLayout(new BoxLayout(shownDetailsPanel, BoxLayout.Y_AXIS));
		
		try {
			updateTurnOrder();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		playerNames.setAlignmentX(JLabel.CENTER_ALIGNMENT);
		turnOrderBox.setAlignmentX(JList.CENTER_ALIGNMENT);
		shownDetailsPanel.setAlignmentX(JPanel.CENTER_ALIGNMENT);
		
		turnOrderBox.setFocusable(false);
		shownDetailsPanel.setFocusable(false);
		
		
		
		panel1Info.add(playerNames);
		panel1Info.add(turnOrderBox);
		panel1Info.add(shownDetailsPanel);
		
		panel1Info.setFocusable(false);
		infoPanel.setFocusable(false);
		infoPanel.add(panel1Info);
		frame.add(BorderLayout.EAST, infoPanel);
		
		
	}
	
	private void updateTurnOrder() throws CloneNotSupportedException {
		engine.PriorityQueue turnOrder = (engine.PriorityQueue) this.gameInstance.getTurnOrder().clone();
		int turnOrderSize = turnOrder.size();
		
		String[] turnOrders = new String[] {"WAITING FOR NEXT TURN..", "WAITING FOR NEXT TURN..", "WAITING FOR NEXT TURN..", "WAITING FOR NEXT TURN..", "WAITING FOR NEXT TURN..", "WAITING FOR NEXT TURN.."};
		
		for(int i=0;i<turnOrderSize;i++) {
			Champion champ = (Champion) turnOrder.remove();
			if(i == 0)
				showDetails(champ);
			turnOrders[i] = champ.getName();
		}
		
		turnOrderBox.setListData(turnOrders);
	}
		
	private void teamPanels(ArrayList<Champion> champions, Map<Champion, JPanel> panels) {
		for(int i=0;i < champions.size();i++) {
			Champion currChamp = champions.get(i);
			
			JPanel championPanel = new JPanel();
			

			championPanel.setLayout(new BorderLayout());
			//championPanel.setSize(this.frame.getWidth()/7, this.frame.getHeight()/7);
			
			//ImageIcon image = this.getChampionImage(currChamp);
        	JButton championImage = new JButton(currChamp.getName());
        	
        	championImage.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					if(abilityType == AreaOfEffect.SINGLETARGET) {
						try {
							gameInstance.castAbility(currAbility, currChamp.getLocation().x, currChamp.getLocation().y);
							updateBoard();
							showDetails(gameInstance.getCurrentChampion());
						} catch (GameActionException | CloneNotSupportedException e) {
							JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
						}
					}
				}
        	});
        	
        	championImage.setFocusPainted(false);
        	championImage.setContentAreaFilled(false);
        	championImage.setBorderPainted(false);
        	if(this.gameInstance.getFirstPlayer().getTeam().contains(currChamp))
        		championPanel.setBorder(BorderFactory.createLineBorder(Color.blue, 3));
        	else
        		championPanel.setBorder(BorderFactory.createLineBorder(Color.red, 3));
        	
        	
        	JProgressBar healthBar = new JProgressBar();
        	healthBar.setBounds(0, 150, 150, 15);
        	healthBar.setForeground(new Color(0, 200, 0));
        	healthBar.setString(currChamp.getCurrentHP() + " / " + currChamp.getMaxHP());
        	healthBar.setValue(100 * (currChamp.getCurrentHP() / currChamp.getMaxHP()));
        	healthBar.setStringPainted(true);
        	
			String appEffects = "";
			if(currChamp.getAppliedEffects().size() == 0)
				appEffects += "NO APPLIED EFFECTS";
			for(Effect eff : currChamp.getAppliedEffects()) {
				appEffects += "<br/>" + eff.getName() + " [DURATION: " + eff.getDuration() + " TURNS]";
			}
			
			
			championImage.setToolTipText(String.format("<html><center>%s (%s)<br/>HP: %s/%s<br/>Mana: %s<br/>Speed: %s<br/>Max Actions Per Turn: %s<br/>Attack Damage: %s<br/>Attack Range: %s<br/>Type: %s<br/><br/><u>Applied Effects</u><br/>%s</center></html>", currChamp.getName(), (this.gameInstance.getFirstPlayer().getLeader() == currChamp || this.gameInstance.getSecondPlayer().getLeader() == currChamp) ? "Leader" : "Non-Leader", currChamp.getCurrentHP(), currChamp.getMaxHP(), currChamp.getMana(), currChamp.getSpeed(), currChamp.getMaxActionPointsPerTurn(), currChamp.getAttackDamage(), currChamp.getAttackRange(), (currChamp instanceof Hero) ? "Hero" : (currChamp instanceof Villain) ? "Villain" : "AntiHero", appEffects));
			 
        	
        	championImage.setFocusable(false);
        	healthBar.setFocusable(false);
        	
        	if(this.gameInstance.getFirstPlayer().getLeader() == currChamp || this.gameInstance.getSecondPlayer().getLeader() == currChamp) {
            	JButton ldrBtn = new JButton();
            	ldrBtn.setFocusable(false);
            	ldrBtn.setBackground(Color.orange);
            	championPanel.add(BorderLayout.NORTH, ldrBtn);
            	this.leaderAbilityIndicators.put(currChamp, ldrBtn);
        	}
        	
        	championPanel.add(BorderLayout.CENTER, championImage);
        	championPanel.add(BorderLayout.SOUTH, healthBar);
        	
        	panels.put(currChamp, championPanel);
        	this.healthBars.put(currChamp, healthBar);
		}
	}
	
	JLabel abilityDetails = new JLabel("", SwingConstants.CENTER);
	
	

	private void showDetails(Champion c) {		
		shownDetailsPanel.removeAll();

		
		//ImageIcon iconImg = this.getChampionImage(c);
		JButton champIcon = new JButton(c.getName());
		champIcon.setBorder(null);
		champIcon.setBackground(null);
		champIcon.setBorderPainted(false);
		champIcon.setFocusPainted(false);
		champIcon.setContentAreaFilled(false);
		
		JLabel champName = new JLabel(c.getName().toUpperCase());
		champName.setFont(new Font("SansSerif", Font.BOLD, 40));
		// champName.setForeground((this.gameInstance.getFirstPlayer().getTeam().contains(c)) ? Color.blue : Color.red);
		champName.setForeground(new Color(15,15,15));
		champName.setAlignmentX(JLabel.CENTER_ALIGNMENT);
		champName.setBorder(BorderFactory.createEmptyBorder(0, 10,20,10));

		
    	JProgressBar healthBar = new JProgressBar();
    	healthBar.setMaximumSize(new Dimension(250, 30));
    	healthBar.setStringPainted(true);
    	healthBar.setForeground(new Color(0, 200, 0));
    	healthBar.setString(c.getCurrentHP() + " / " + c.getMaxHP());
    	healthBar.setValue(100 * (c.getCurrentHP() / c.getMaxHP()));
    	healthBar.setAlignmentX(JProgressBar.CENTER_ALIGNMENT);
    	healthBar.setBorderPainted(false);
    	
		champIcon.setFocusable(false);
						
		
		JLabel cType = new JLabel("Type: " + ((c instanceof Hero) ? "Hero" : (c instanceof Villain) ? "Villain" : "AntiHero"));
		cType.setAlignmentX(0.5f);
		cType.setBorder(BorderFactory.createEmptyBorder(20, 10,0,10));

		
		JLabel cMana = new JLabel("Mana: " + c.getMana());
		cMana.setAlignmentX(0.5f);
		
		JLabel cActionPoints = new JLabel("Action Points: " + c.getCurrentActionPoints());
		cActionPoints.setAlignmentX(0.5f);
		
		JLabel cDamage = new JLabel("Attack Damage: " + c.getAttackDamage() + " health points");
		cDamage.setAlignmentX(0.5f);
		
		JLabel cAttackRange = new JLabel("Attack Range: " + c.getAttackRange());
		cAttackRange.setAlignmentX(0.5f);
		cAttackRange.setBorder(BorderFactory.createEmptyBorder(0, 10,20,10));

		
		JList<String> EffectsList = new JList<String>();
		EffectsList.setFixedCellWidth(screenSize.width - 1000);
		EffectsList.setFixedCellHeight(20);
		EffectsList.setFocusable(false);
		EffectsList.setAlignmentX(JList.CENTER_ALIGNMENT);
		
		ArrayList<String> effData = new ArrayList<String>();
		effData.add("EFFECTS");
		if(c.getAppliedEffects().size() == 0)
			effData.add("NO APPLIED EFFECTS");
		for(Effect eff : c.getAppliedEffects()) {
			effData.add(eff.getName() + " [DURATION: " + eff.getDuration() + " TURNS]");
		}
		
		EffectsList.setListData(effData.toArray(new String[0]));
		DefaultListCellRenderer renderer = (DefaultListCellRenderer) EffectsList.getCellRenderer();
		renderer.setHorizontalAlignment(SwingConstants.CENTER);
		
		shownDetailsPanel.add(champIcon);
		shownDetailsPanel.add(champName); 
		shownDetailsPanel.add(healthBar);

		shownDetailsPanel.add(cType);
		shownDetailsPanel.add(cMana);
		shownDetailsPanel.add(cActionPoints);
		shownDetailsPanel.add(cDamage);
		shownDetailsPanel.add(cAttackRange);
		
		shownDetailsPanel.add(EffectsList);

		
		champIcon.setAlignmentX(JButton.CENTER_ALIGNMENT);

		JPanel AbilityList = new JPanel();
		AbilityList.setLayout(new GridLayout(1,3));
		
		ArrayList<Ability> champAbilities = c.getAbilities();
		abilityDetails.setAlignmentX(JLabel.CENTER_ALIGNMENT);
		
		for(int i=0; i<champAbilities.size();i++) {
			Ability ability = champAbilities.get(i);
			JButton abilityBtn = new JButton();
			abilityBtn.setText(ability.getName());
			abilityBtn.setFocusable(false);
			
			abilityBtn.setFocusPainted(false);
			abilityBtn.setForeground(Color.white);
			
			abilityBtn.setBackground(new Color(15,15,15));
			// RIGHT , LEFT RIGHT, LEFT
			abilityBtn.setBorder(BorderFactory.createMatteBorder(0, (i!=0) ? 2 : 0, 0, (i!=2) ? 2 : 0, Color.black));
			
			AbilityList.add(abilityBtn);
			String championText = "<html>";
			abilityBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
		        	String abilityName = ability.getName();
		        	String abilityStringBuilder = "";
		        	abilityStringBuilder += "<center>" + abilityName + "<br/>" + ( (ability instanceof CrowdControlAbility) ? "Crowd Control (" + ((CrowdControlAbility) ability).getEffect() + ")" : (ability instanceof DamagingAbility) ? "Damaging Ability (DMG: " + ((DamagingAbility) ability).getDamageAmount() + ")" : "Healing Ability (HEL: " + ((HealingAbility) ability).getHealAmount() + ")") + "<br/>Base Cool Down: "+ability.getBaseCooldown()+" turns | Current Cool Down: " +ability.getCurrentCooldown()+ "<br/>Area Of Effect: "+ability.getCastArea()+" | Range: " + ability.getCastRange() + "<br/>Mana Cost: " +ability.getManaCost()+ " | Action Points Required: " +ability.getRequiredActionPoints() + "<br/></center>";
		        	abilityDetails.setText(championText + "<br/>" + abilityStringBuilder);
		        	abilityDetails.setForeground(Color.white);
		        	abilityDetails.setFocusable(false);
		    		resetHighlighted();
		        	
					AreaOfEffect castArea = ability.getCastArea();
					abilityType = castArea;
					currAbility = ability;
					
					if(castArea == AreaOfEffect.SELFTARGET) {
						if(playerOneChampionsPanels.containsKey(c)) {
							playerOneChampionsPanels.get(c).setBackground(COL_HIGHLIGHT);
						} else {
							playerTwoChampionsPanels.get(c).setBackground(COL_HIGHLIGHT);
						}
					} else if(castArea == AreaOfEffect.DIRECTIONAL) {
						int champX = 4- c.getLocation().x;
						int champY = 4 - c.getLocation().y;
						if(champX+1 != 5)
							grid[champX+1][champY].setBackground(COL_HIGHLIGHT);
						
						if(champX-1 != -1)
							grid[champX-1][champY].setBackground(COL_HIGHLIGHT);
						
						if(champY+1 != 5)
							grid[champX][champY+1].setBackground(COL_HIGHLIGHT);
						
						if(champY-1 != -1)
							grid[champX][champY-1].setBackground(COL_HIGHLIGHT);
						
						
					} else if(castArea == AreaOfEffect.SURROUND) {
						for(int x=0;x<5;x++) {
							for(int y=0;y<5;y++) {
								int xDiff = Math.abs((4-c.getLocation().x) - x);
								int yDiff = Math.abs((4-c.getLocation().y) - y);
								if(xDiff <= 1 &&  yDiff <= 1 && xDiff + yDiff != 0) {
									JPanel jp = (JPanel) grid[x][y];
									jp.setBackground(COL_HIGHLIGHT);
								}
							}
						}
					} else if(castArea == AreaOfEffect.SINGLETARGET) {
						for(int x=0;x<5;x++) {
							for(int y=0;y<5;y++) {
								int xDiff = Math.abs((4-c.getLocation().x) - x);
								int yDiff = Math.abs((4-c.getLocation().y) - y);
								int manH = xDiff + yDiff;
								if(manH <= ability.getCastRange()) {
									JPanel jp = (JPanel) grid[x][y];
									jp.setBackground(COL_HIGHLIGHT);
								}
							}
						}
					} else {
						// teamtarget
						ArrayList<JPanel> enemies = new ArrayList<JPanel>();
						ArrayList<JPanel> allies = new ArrayList<JPanel>();
						ArrayList<JPanel> covers = new ArrayList<JPanel>();
						
						ArrayList<Champion> enemiesC = new ArrayList<Champion>();
						ArrayList<Champion> alliesC = new ArrayList<Champion>();
						ArrayList<Cover> coversC = new ArrayList<Cover>();
						
						((JPanel)grid[0][0]).setBorder(null);
						
						for(int x=0;x<5;x++) {
							for(int y=0;y<5;y++) {
								int realX = (4-x); // COORDS ON BOARD
								int realY = (4-y);
								int xDiff = Math.abs(realX - c.getLocation().x);
								int yDiff = Math.abs(realY - c.getLocation().y);
								int manH = xDiff + yDiff;
								if(manH <= ability.getCastRange()) {
									Damageable obj = (Damageable) gameInstance.getBoard()[realX][realY];
									if(obj instanceof Champion) {
										if(gameInstance.getFirstPlayer().getTeam().contains(gameInstance.getCurrentChampion()) && gameInstance.getFirstPlayer().getTeam().contains((Champion) obj)) {
											// Ally
											allies.add((JPanel) grid[x][y]);
											alliesC.add((Champion) gameInstance.getBoard()[realX][realY]);
											System.out.println("added ally 1");
										} else if(gameInstance.getSecondPlayer().getTeam().contains(gameInstance.getCurrentChampion()) && gameInstance.getSecondPlayer().getTeam().contains((Champion) obj)) {
											allies.add((JPanel) grid[x][y]);
											alliesC.add((Champion) gameInstance.getBoard()[realX][realY]);
											System.out.println("added ally 2");
										} else {
											enemies.add((JPanel) grid[x][y]);
											enemiesC.add((Champion) gameInstance.getBoard()[realX][realY]);
											System.out.println("added enemy");
										}
									} else {
										covers.add((JPanel) grid[x][y]);
										coversC.add((Cover) gameInstance.getBoard()[realX][realY]);
										System.out.println("added cover");
									}
								}
							}
						}
						
						if(ability instanceof DamagingAbility) {
							for(JPanel jp : enemies) {
								jp.setBackground(COL_HIGHLIGHT);
							}
							
							for(JPanel jp : covers) {
								jp.setBackground(COL_HIGHLIGHT);
							}
						} else if(ability instanceof CrowdControlAbility) {
							if(((CrowdControlAbility) ability).getEffect().getType() == EffectType.DEBUFF) {
								for(JPanel jp : enemies) {
									jp.setBackground(COL_HIGHLIGHT);
								}
							} else {
								for(JPanel jp : allies) {
									jp.setBackground(COL_HIGHLIGHT);
								}
							}
						} else if(ability instanceof HealingAbility) {
							for(JPanel jp : allies) {
								jp.setBackground(COL_HIGHLIGHT);
							}
						}
					}
		        	
		        	shownDetailsPanel.add(abilityDetails);

		        	shownDetailsPanel.revalidate();
				}
			});
		}
		
		AbilityList.setMaximumSize(new Dimension(this.screenSize.width - 1000, 50));
		AbilityList.setMinimumSize(new Dimension(this.screenSize.width - 1000, 50));
		
		AbilityList.setFocusable(false);
		shownDetailsPanel.add(AbilityList);
		

		shownDetailsPanel.repaint();
		shownDetailsPanel.revalidate();
	}
	Color c1 = new Color(10, 10, 10);
	Color c2 = new Color(50, 50, 50);

	private void resetHighlighted() {
		boolean altColor = true;

		for(int x=0;x<5;x++) {
			for(int y=0;y<5;y++) {
				altColor = !altColor;
				grid[x][y].setBackground((altColor) ? c1 : c2);
			}
		}
	}
	
	private void coverPanels(ArrayList<Cover> coversList, Map<Cover, JPanel> panels) {
		for(int i=0;i < coversList.size();i++) {
			Cover currChamp = coversList.get(i);
			JPanel coverPanel = new JPanel();
			coverPanel.setLayout(new BorderLayout());
			//coverPanel.setSize(this.frame.getWidth()/7, this.frame.getHeight()/);
			
			//ImageIcon image = this.getCoverImage();
        	JButton coverImage = new JButton("Cover");
        	
        	coverImage.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent f) {
					if(abilityType == AreaOfEffect.SINGLETARGET) {
						try {
							gameInstance.castAbility(currAbility, currChamp.getLocation().x, currChamp.getLocation().y);
							updateBoard();
							showDetails(gameInstance.getCurrentChampion());
						} catch (GameActionException | CloneNotSupportedException e) {
							JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
						}
					}					
				}
        		
        	});
        	
        	coverImage.setFocusPainted(false);
        	coverImage.setContentAreaFilled(false);
        	coverImage.setBorderPainted(false);
        	coverImage.setBounds(0, 0, this.frame.getWidth()/7, this.frame.getHeight()/7);
        	
        	JProgressBar healthBar = new JProgressBar();
        	healthBar.setBounds(0, 150, 150, 15);
        	healthBar.setStringPainted(true);
        	healthBar.setForeground(new Color(200, 0, 200));
        	healthBar.setString(currChamp.getCurrentHP() + " / " + currChamp.getMaxHP());
        	healthBar.setValue(100 * (currChamp.getCurrentHP() / currChamp.getMaxHP()));
        	
        	coverImage.setFocusable(false);
        	healthBar.setFocusable(false);
        	coverPanel.add(BorderLayout.NORTH, coverImage);
        	coverPanel.add(BorderLayout.SOUTH, healthBar);
        	
        	coverPanel.setBorder(BorderFactory.createLineBorder(Color.black));
        	
        	panels.put(currChamp, coverPanel);
        	this.healthBars.put(currChamp, healthBar);
		}
	}
	
	private void updateBoard() {
		boolean altColor = true;

		this.boardPanel.removeAll();
		for(int x=0;x<5;x++) {
			for(int y=4;y>=0;y--) {
				Damageable boardObj = (Damageable) this.gameInstance.getBoard()[4-x][4-y];
				altColor = !altColor;

				if(boardObj == null) {
					JPanel label = new JPanel();
					label.setBorder(BorderFactory.createLineBorder(Color.black));
					label.setBackground((altColor) ? c1 : c2);

					label.setFocusable(false);
					this.boardPanel.add(label);
					grid[x][y] = label;
					continue;
				}
				
				JProgressBar healthBar = healthBars.get(boardObj);
				Double currHP = (double) boardObj.getCurrentHP();
				
				Double healthP = 100.0 * (currHP / boardObj.getMaxHP());
				
				healthBar.setValue(healthP.intValue());
				healthBar.setString(boardObj.getCurrentHP() + " / " + boardObj.getMaxHP());
				
				healthBar.repaint();
				healthBar.revalidate();

				JPanel jp;
				if(boardObj instanceof Champion) {
					Champion champ = (Champion) boardObj;
					if(this.gameInstance.getFirstPlayer().getTeam().contains(champ)) { // firstteam
						jp = this.playerOneChampionsPanels.get(champ);
					} else {
						jp = this.playerTwoChampionsPanels.get(champ);
					}
				} else {
					jp = this.coversPanels.get((Cover) boardObj);
				}
				
				jp.setBackground((altColor) ? c1 : c2);
				this.boardPanel.add(jp);
				grid[x][y] = jp;
				jp.repaint();
			}
		}
		this.boardPanel.revalidate();
		this.boardPanel.repaint();
 	}
	
	/*private ImageIcon getChampionImage(Champion c) {
    	String imagePath = ".\\src\\Images\\" + c.getName() + ".png";
        ImageIcon imageForOne = new ImageIcon(imagePath);
        imageForOne = new ImageIcon(imageForOne.getImage().getScaledInstance(140, 140, Image.SCALE_SMOOTH));
        
        return imageForOne;
	}
	
	private ImageIcon getCoverImage() {
    	String imagePath = ".\\src\\Images\\cover.png";
        ImageIcon imageForOne = new ImageIcon(imagePath);
        imageForOne = new ImageIcon(imageForOne.getImage().getScaledInstance(140, 140, Image.SCALE_SMOOTH));
        
        return imageForOne;
	}*/

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	boolean gameEnded = false;
	boolean atkReady = false;
	@Override
	public void keyReleased(KeyEvent arg0) {
		if(!gameEnded) {
			try {
				if(arg0.getKeyCode() == KeyEvent.VK_W) {
					try {
						if(!atkReady && abilityType == null) {
							this.gameInstance.move(Direction.UP);
						} else if(atkReady) {
							this.gameInstance.attack(Direction.UP);
						} else if(abilityType == AreaOfEffect.DIRECTIONAL) {
							this.gameInstance.castAbility(currAbility, Direction.UP);
						}
						this.resetHighlighted();
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
					} catch(GameActionException e) {
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
						JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
				} else if(arg0.getKeyCode() == KeyEvent.VK_A) {
					try {
						if(!atkReady && abilityType == null) {
							this.gameInstance.move(Direction.LEFT);
						} else if(atkReady) {
							this.gameInstance.attack(Direction.LEFT);
						} else if(abilityType == AreaOfEffect.DIRECTIONAL) {
							this.gameInstance.castAbility(currAbility, Direction.LEFT);
						}
						this.resetHighlighted();
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
					} catch(GameActionException e) {
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
						JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
				} else if(arg0.getKeyCode() == KeyEvent.VK_D) {
					try {
						if(!atkReady && abilityType == null) {
							this.gameInstance.move(Direction.RIGHT);
						} else if(atkReady) {
							this.gameInstance.attack(Direction.RIGHT);
						} else if(abilityType == AreaOfEffect.DIRECTIONAL) {
							this.gameInstance.castAbility(currAbility, Direction.RIGHT);
						}
						this.resetHighlighted();
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
					} catch(Exception e) {
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
						JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
				} else if(arg0.getKeyCode() == KeyEvent.VK_S) {
					try {
						if(!atkReady && abilityType == null) {
							this.gameInstance.move(Direction.DOWN);
						} else if(atkReady) {
							this.gameInstance.attack(Direction.DOWN);
						} else if(abilityType == AreaOfEffect.DIRECTIONAL) {
							this.gameInstance.castAbility(currAbility, Direction.DOWN);
						}
						this.resetHighlighted();
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
					} catch(Exception e) {
						atkReady = false;
						abilityType = null;
						this.currAbility = null;
						JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					}
				} else if(arg0.getKeyCode() == KeyEvent.VK_SPACE) {
					atkReady = true;
				} else if(arg0.getKeyCode() == KeyEvent.VK_E) {
					this.gameInstance.endTurn();
					this.abilityType = null;
					this.atkReady = false;
					this.currAbility = null;
					Player winningPlayer = this.gameInstance.checkGameOver();
					if(winningPlayer != null) {
						JOptionPane.showMessageDialog(null, winningPlayer.getName() + " wins!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
						gameEnded = true;
						this.shownDetailsPanel.setVisible(false);
						return;
					}
					this.updateBoard();
					this.updateTurnOrder();
				} else if(arg0.getKeyCode() == KeyEvent.VK_C) {
					this.resetHighlighted();
					if(abilityType == AreaOfEffect.SELFTARGET || abilityType == AreaOfEffect.SURROUND || abilityType == AreaOfEffect.TEAMTARGET) {
						gameInstance.castAbility(currAbility);
					}
				} else if(arg0.getKeyCode() == KeyEvent.VK_Q) {
					this.gameInstance.useLeaderAbility();
					Champion currChamp = this.gameInstance.getCurrentChampion();
					leaderAbilityIndicators.get(currChamp).setBackground(Color.gray);
				} else if(arg0.getKeyCode() == KeyEvent.VK_C) {
					this.abilityType = null;
					this.atkReady = false;
					this.currAbility = null;
					this.resetHighlighted();
				}
			} catch (GameActionException | CloneNotSupportedException e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
			this.updateBoard();
			this.showDetails(this.gameInstance.getCurrentChampion());
		}
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	

		  
	
}
